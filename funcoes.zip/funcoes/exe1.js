const calcularAreaRetangulo = (base, altura) => {
  const resultado = base * altura;
  return resultado;
};
console.log(calcularAreaRetangulo(2, 3));

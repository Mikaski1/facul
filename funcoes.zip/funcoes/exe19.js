const produtos = [
{ id: 1, nome: "Teclado", preco: 150, estoque: 5 },
{ id: 2, nome: "Mouse", preco: 80, estoque: 0 },
{ id: 3, nome: "Monitor", preco: 900, estoque: 2 }
];
function buscarProdutoPorId(id) {
  const produto = produtos.find((produto) => produto.id === id);
  return produto ? produto : "Produto não encontrado";
}
console.log(buscarProdutoPorId(1));
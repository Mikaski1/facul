const produtos = [
{ id: 1, nome: "Teclado", preco: 150, estoque: 5 },
{ id: 2, nome: "Mouse", preco: 80, estoque: 0 },
{ id: 3, nome: "Monitor", preco: 900, estoque: 2 }
];

const produtosDisponiveis = produtos.filter((produto) => produto.estoque > 0);
const nomesProdutos = produtosDisponiveis.map((produto) => produto.nome);
const listaProdutos = nomesProdutos.reduce((lista, nome) => lista + nome + " | ", "Produtos disponíveis: ");
console.log(listaProdutos);
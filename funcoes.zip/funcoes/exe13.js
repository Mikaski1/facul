const numeros = [5, 10, 15, 20, 25];

const reduzir = numeros.reduce((acumulador, numero) => acumulador + numero, 0);
console.log(reduzir);

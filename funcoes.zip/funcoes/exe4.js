﻿function saudacao(nome, turno) {
  if (turno === "M") {
    return `Bom dia, ${nome}!`;
  } else if (turno === "V") {
    return `Boa tarde, ${nome}!`;
  } else if (turno === "N") {
    return `Boa noite, ${nome}!`;
  } else {
    return "Turno inválido.";
  }
}
console.log(saudacao("Anthony", "M"));



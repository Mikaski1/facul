const colaboradores = [
{ nome: "Roberto", salario: 2000,},
{ nome: "Carlos", salario: 1000,}, 
{ nome: "Vitor", salario: 1500,}
];

function consolidarFolha(colaboradores) {
  const resultado = colaboradores.reduce((acumulador, colaborador) => {
    return {
      totalGasto: acumulador.totalGasto + colaborador.salario,
      totalFuncionarios: acumulador.totalFuncionarios + 1
    };
  }, { totalGasto: 0, totalFuncionarios: 0 });

  return {
    totalGasto: resultado.totalGasto,
    mediaSalarios: resultado.totalGasto / resultado.totalFuncionarios,
    totalFuncionarios: resultado.totalFuncionarios
  };
}

const relatorio = consolidarFolha(colaboradores);
console.log(relatorio);

function CparaF(celsius) {
  const fahrenheit = celsius * 1.8 + 32;
  return fahrenheit;
}
console.log(CparaF(20));

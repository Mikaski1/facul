const numeros = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
const resultado = numeros
  .filter((n) => n % 2 === 0)
  .map((n) => n * 2)
  .reduce((total, atual) => total + atual, 0);
console.log(resultado);

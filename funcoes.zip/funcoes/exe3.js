function par(n) {
  if (n % 2 === 0) {
    return "par";
  } else {
    return "impar";
  }
}
console.log(par(4));

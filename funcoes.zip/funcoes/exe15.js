const frutas = ["maçã", "banana", "maçã", "laranja", "banana", "maçã"];

const quantidadeFrutas = frutas.reduce((contador, fruta) => {
  contador[fruta] = (contador[fruta] || 0) + 1;
  return contador;
}, {});
console.log(quantidadeFrutas);

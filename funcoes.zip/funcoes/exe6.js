const alunos = [
  { nome: "Ana", nota: 8.5, presenca: 90 },
  { nome: "Pedro", nota: 5.0, presenca: 75 },
  { nome: "Maria", nota: 9.2, presenca: 60 },
  { nome: "João", nota: 6.8, presenca: 95 },
];
const aprovados = alunos.filter((aluno) => aluno.nota >= 7);
console.log(aprovados);

const alunos = [
  { nome: "Ana", nota: 8.5, presenca: 90 },
  { nome: "Pedro", nota: 5.0, presenca: 75 },
  { nome: "Maria", nota: 9.2, presenca: 60 },
  { nome: "João", nota: 6.8, presenca: 95 },
];

const media =
  alunos.reduce((acumulador, aluno) => acumulador + aluno.nota, 0) /
  alunos.length;
console.log(media.toFixed(2));

const tecnologias = ["java", "javascript", "python", "html", "css"];

const filtrar = tecnologias.filter((tecnologia) => tecnologia.length > 4);
console.log(filtrar);

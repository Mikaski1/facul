const numeros = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

const maximo = numeros.reduce((max, numero) => numero > max ? numero : max, numeros[0]);
console.log(maximo);

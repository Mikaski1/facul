const precos = [10, 25, 47, 80];

const desconto = precos.map((preco) => (preco * 0.9).toFixed(2));
console.log(desconto);

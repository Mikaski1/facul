/* MULTIPLICAÇÃO
let n1;
let n2;

n1 = window.prompt("Escreva o primeiro número para multiplicar");
n2 = window.prompt("Escreva o segundo número para multiplicar");
n1 = Number(n1);
n2 = Number(n2)

multiplicacao = n1 * n2

console.log("O resultado é:", multiplicacao);
*/

/* SOMA
let n1;
let n2;

n1 = window.prompt("Escreva o primeiro número para soma");
n2 = window.prompt("Escreva o segundo número para soma");
n1 = Number(n1);
n2 = Number(n2)

soma = n1 + n2

console.log("O resultado é:", soma);
*/

/* raio
let n1;
let pi
pi = 3.14

n1 = window.prompt("Escreva o primeiro número para raio");
n1 = Number(n1);

raio = n1 * n1 * pi

console.log("O resultado é:", raio);
*/


/* CONVERSAO
let F;

F = window.prompt("Escreva o primeiro número para fahrenheit");
F = Number(F);

conversao = (F - 32) / 1.8
console.log("O resultado é:", conversao);
*/

/* SALARIO
let n1;
let n2;

n1 = window.prompt("Escreva o primeiro número para horas");
n2 = window.prompt("Escreva o segundo número para ganho por hora");
n1 = Number(n1);
n2 = Number(n2)

salario = n1 * n2

console.log("O resultado é :$", salario);
*/

/* MÉDIA
let n1;
let n2;

n1 = window.prompt("Escreva o primeiro número para média");
n2 = window.prompt("Escreva o segundo número para média");
n1 = Number(n1);
n2 = Number(n2)

media = (n1 + n2) /2

console.log("O resultado é:", media);
*/

/* ANTECESSOR
let n1;
let n2;

n1 = window.prompt("Escreva o primeiro número para anteceder");
n1 = Number(n1);

antecessor = n1 - 1

console.log("O resultado é:", antecessor);
*/

/* SUCESSOR
let n1;
let n2;

n1 = window.prompt("Escreva o primeiro número para suceder");
n1 = Number(n1);

sucessor = n1 + 1

console.log("O resultado é:", sucessor);
*/

/* metros em centimetros
let n1;
let n2;

n1 = window.prompt("Escreva o primeiro número para transformar metros em centimetros");
n1 = Number(n1);

centimetros = n1 * 100

console.log("O resultado é:", centimetros);
*/

/* DIVISAO
let n1;
let n2;

n1 = window.prompt("Escreva o primeiro número para distancia");
n2 = window.prompt("Escreva o segundo número para combustivel");
n1 = Number(n1);
n2 = Number(n2)

divisao = n1 / n2

console.log("O resultado é:", divisao);
*/